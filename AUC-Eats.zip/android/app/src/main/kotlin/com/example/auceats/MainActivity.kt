package com.example.auceats

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
